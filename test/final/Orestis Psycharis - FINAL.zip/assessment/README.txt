Instructions for part 1 can be found in the index.html files contained in the a, b, and c folders. Instructions for part 2 can be found in the file named script.js in the part2 folder.

To complete these exercises you will need to use a text editor. While both Windows
and OS X have text editors pre-installed, it is recommended that you download
and install Visual Studio Code from https://code.visualstudio.com/download.
